﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {



            // try-catch
            try
            {
                //byte texto = Convert.ToByte(txtIngreso.Text);
                //lblMostrar.Text = texto.ToString();

                if (txtIngreso.Text == "Admin" && txtContra.Text =="1234")
                {
                    this.Hide();
                    Programa frm = new Programa();
                    frm.Show();

                }
                else
                {
                    MessageBox.Show("Usuario incorrecto");
                    
                }
            }
            catch (OverflowException y)
            {

                MessageBox.Show("el erro es: "+y);
            }
            catch(System.FormatException v)
            {
                MessageBox.Show("el erro es: " + v);
            }
        }

        private void txtIngreso_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_MouseHover(object sender, EventArgs e)
        {

        }
    }
}
