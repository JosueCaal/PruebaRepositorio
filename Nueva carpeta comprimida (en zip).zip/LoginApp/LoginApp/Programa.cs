﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LoginApp
{
    public partial class Programa : Form
    {
        public Programa()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            


        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            int nota1 = int.Parse(txtNota1.Text);
            int nota2 = int.Parse(txtNota2.Text);

            int promedio = (nota1 + nota2)/2;

            if(nota1 >100)
            {

                MessageBox.Show("nota 1 no pude ser mayor que 100");
                if (nota2>100)
                {
                    MessageBox.Show("Nota 2 no puede ser mayor que 100");
                   
                }
            }

        }
    }
}
